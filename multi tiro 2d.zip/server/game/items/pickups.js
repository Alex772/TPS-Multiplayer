const { getItemDefinition } = require('./itemRules');
const { getVisibleWorldItems, removeWorldItem } = require('./worldItems');
const { createWeaponInstance } = require('../players');
const { setScopeItem, addMeds } = require('./inventory');
const { spawnDroppedItem } = require('./worldItems');

const PICKUP_RADIUS = 0.65;

function canWeaponUseScope(weaponDef, zoom) {
  const allowed = weaponDef?.scope?.allowed || [];
  return allowed.includes(zoom);
}

function applyItemToPlayer(player, item) {
  const definition = getItemDefinition(item.id);
  if (!definition) return false;

  switch (definition.type) {
    case 'weapon': {
      const slot = definition.slot || 'primary';
      player.loadout[slot] = createWeaponInstance(definition.weaponId);
      if (slot !== 'secondary') player.loadout.current = slot;
      if (player.activeScope && player.activeScope > 1) {
        const currentWeapon = player.loadout[player.loadout.current];
        if (!canWeaponUseScope(currentWeapon.weaponDef, player.activeScope)) {
          player.activeScope = 1;
        }
      }
      return true;
    }
    case 'scope': {
      const zoom = Number(definition.zoom || 1);
      const previous = setScopeItem(player, zoom);
      const currentWeapon = player.loadout?.current ? player.loadout[player.loadout.current] : null;
      player.activeScope = canWeaponUseScope(currentWeapon?.weaponDef, zoom) ? zoom : 1;
      if (previous && previous > 1 && previous !== zoom) {
        spawnDroppedItem(`scope_${previous}x`, player.x + 0.18, player.y - 0.12, 1, 12000);
      }
      return true;
    }
    case 'heal':
      addMeds(player, 1);
      player.hp = Math.min(100, player.hp + Number(definition.amount || 0));
      return true;
    case 'ammo': {
      const current = player.loadout?.current ? player.loadout[player.loadout.current] : null;
      if (current) current.magsLeft += Number(definition.mags || 1);
      return true;
    }
    default:
      return false;
  }
}

function tryPickupNearbyItems(player, now = Date.now()) {
  if (!player || player.hp <= 0) return;
  const items = getVisibleWorldItems(now);
  for (const item of items) {
    const dist = Math.hypot(item.x - player.x, item.y - player.y);
    if (dist > PICKUP_RADIUS) continue;
    if (applyItemToPlayer(player, item)) {
      removeWorldItem(item.worldId, now);
    }
  }
}

module.exports = { tryPickupNearbyItems };
